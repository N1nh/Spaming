<?php
$i = rand(0, 5);
// echo $i;
switch ($i)
{
    case 0:
        $mail->Encoding = 'base64';
    break;
    case 1:
        $mail->Encoding = '8bit';

    break;
    case 2:
        $mail->Encoding = '7bit';

    break;
    case 3:
        $mail->Encoding = 'binary';

    break;
    case 4:
        $mail->Encoding = 'quoted-printable';

    break;

}
$a = rand(0, 1);
// echo $i;
switch ($a)
{
    case 0:
        $mail->CharSet = 'UTF-8';
    break;
    case 1:
        $mail->CharSet = 'ISO-8859-1 ';
    break;

}

