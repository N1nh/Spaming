<?php
$json = file_get_contents('./gen/first-names.json');
 $fname = json_decode($json, true);

//var_dump($array); // print array
$firstname = $fname[rand(0,count($fname))];

$json2 = file_get_contents('./gen/last-names.json');
$lname = json_decode($json, true);
$lastname = $lname[rand(0,count($lname))];
$number = rand(1, 100000);
 echo $sendername = $firstname.' '.$lastname.' '.$number;