# HyperX

HyperX is a php library for spaming using SMTP-GOOGLE.

## Installation

Lastest [PHP](https://www.php.net/downloads.php) to run HyperX.
*ADD IT TO ENVIRONMENT PATH

```bash
Install 2FA for your Gmail account.
Set App Password (https://myaccount.google.com/u/1/apppasswords)
[MUST ENABLE 2FA FIRST]


*****IP*****
Run 'ip.exe'
> To check your external IP address. If your IP not recognize by the system.
Please contact @MeoDeThuong or @Nononononooooou8


*****API*****
inside 'api.txt'


*****SMTP*****
inside 'smtp.txt'
> Tool will random between each SMTP in file.


*****TARGET*****
inside 'target.txt'
`#` > ONLY 1 TARGET!!!!!!!!!!


*****SUBJECT*****
inside Folder: '\subject'
Example: 1.txt, 2.txt, 3.txt (CREAT NEW SUBJECT LIKE THIS FORMAT)
random tag:  ;;random country;; && ;;random-number;;


*****LETTER*****
inside Folder: '\noidung'
Example: 1.txt, 2.txt, 3.txt (CREAT NEW SUBJECT LIKE THIS FORMAT) (inside can be html code)
random tag:  ;;random country;; && ;;random-number;; && ;;random devices;;
```

## Usage

```python
php hyper.php [to exec the tool]
run ip.exe [in 'ip' folder to check the ip address]
```

## Contributing
Creator: @Nononononooooou8

Admin: @MeoDeThuong

## License
[Admin CuteCat](https://t.me/meodethuong)
[Admin HyperX](https://t.me/Nononononooooou8)