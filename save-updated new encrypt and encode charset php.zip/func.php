
<?php
// outputs the username that owns the running php/httpd process

// (on a system with the "whoami" executable in the path)
$cmd = 'python3 ./html-classes-obfuscator/html_classes_obfuscator/html_classes_obfuscator.py --htmlpath="'.$encrypt.'" --csspath="'.$path.'/noidung/empty/css.css" --jspath="'.$path.'/noidung/empty/js.js"';
$output = shell_exec($cmd);
echo 'Html file encrypted!'."\n"."\n";
?> 