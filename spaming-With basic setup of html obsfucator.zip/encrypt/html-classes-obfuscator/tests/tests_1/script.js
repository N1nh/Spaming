const app

// No modifications
document.querySelector("section");
document.querySelectorAll("section");
app.querySelectorAll("section");

// Do modifications
document.querySelector(".parent");
document.querySelectorAll(".parent");
app.querySelectorAll(".parent");
app.classList.toggle("parent");
