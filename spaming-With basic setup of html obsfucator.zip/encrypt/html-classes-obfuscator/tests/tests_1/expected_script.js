const app

// No modifications
document.querySelector("section");
document.querySelectorAll("section");
app.querySelectorAll("section");

// Do modifications
document.querySelector(".test_3");
document.querySelectorAll(".test_3");
app.querySelectorAll(".test_3");
app.classList.toggle("test_3");
